﻿namespace GrindOMeter.Model.EntityAdaptor
{
    using System;

    class EntityAdaptorException : Exception
    {
        public EntityAdaptorException(string msg) : base(msg) { }
    }
}

