﻿namespace GrindOMeter.Model.Entity
{
    public interface IEntitySample
    {
        int Amount { get; }
        double Timestamp { get; }
    }
}