﻿namespace GrindOMeter.Presenter
{
    using System.Collections.Generic;
    using View;

    public class EntitySelection : Dictionary<string, List<ITrackableEntity>>, IEntitySelection
    {
         
    }
}