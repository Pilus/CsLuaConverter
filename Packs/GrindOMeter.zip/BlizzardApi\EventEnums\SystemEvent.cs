﻿namespace BlizzardApi.EventEnums
{
    public enum SystemEvent
    {
        ADDON_ACTION_BLOCKED,
        ADDON_ACTION_FORBIDDEN,
        ADDON_LOADED,
        VARIABLES_LOADED,
    }
}