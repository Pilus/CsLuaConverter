﻿
namespace GrindOMeter.View
{
    using System.Collections.Generic;

    public interface IEntitySelection : IDictionary<string, List<ITrackableEntity>>
    {
    }
}
