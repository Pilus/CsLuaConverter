﻿
namespace GrindOMeter.Model.Entity
{
    public enum EntityType
    {
        Currency,
        Item,
    }
}
