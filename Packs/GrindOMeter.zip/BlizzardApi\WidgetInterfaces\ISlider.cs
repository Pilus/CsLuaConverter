﻿namespace BlizzardApi.WidgetInterfaces
{
    using CsLuaFramework.Attributes;

    [ProvideSelf]
    public interface ISlider : IFrame
    {
         
    }
}