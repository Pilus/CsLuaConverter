﻿namespace GrindOMeter.Model
{
    using System;

    class ModelException : Exception
    {
        public ModelException(string msg) : base(msg) { }
    }
}
