﻿namespace WoWSimulator.UISimulation
{
    using System;

    public class UiSimuationException : Exception
    {
        public UiSimuationException(string msg) : base(msg)
        {
            
        }
    }
}