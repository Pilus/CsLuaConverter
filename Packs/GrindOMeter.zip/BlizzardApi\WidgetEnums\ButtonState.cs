﻿namespace BlizzardApi.WidgetEnums
{
    
    public enum ButtonState
    {
        PUSHED,
        NORMAL,
    }
}
