﻿

namespace BlizzardApi.Global
{
    using WidgetInterfaces;

    public partial interface IApi
    {
        void InterfaceOptions_AddCategory(IFrame frame);
    }
}
