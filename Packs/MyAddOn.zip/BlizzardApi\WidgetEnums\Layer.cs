﻿namespace BlizzardApi.WidgetEnums
{
    public enum Layer
    {
        BACKGROUND,
        BORDER,
        ARTWORK,
        OVERLAY,
        HIGHLIGHT
    }
}