﻿namespace BlizzardApi.WidgetEnums
{
    public enum Orientation
    {
        HORIZONTAL,
        VERTICAL,
    }
}