﻿namespace BlizzardApi.WidgetEnums
{
    public enum MouseButton
    {
        RightButton,
        LeftButton,
    }
}