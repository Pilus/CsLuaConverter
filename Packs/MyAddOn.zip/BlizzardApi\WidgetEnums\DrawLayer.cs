﻿namespace BlizzardApi.WidgetEnums
{
    public enum DrawLayer
    {
        BACKGROUND,     
        BORDER,
        ARTWORK,
        OVERLAY,
        HIGHLIGHT,
    }
}