﻿
namespace $safeprojectname$
{
    using CsLuaAttributes;

    [CsLuaAddOn("$safeprojectname$", "$projectname$", 60200, Author = "$username$")]
    public class $safeprojectname$AddOn : ICsLuaAddOn
    {
        public void Execute()
        {
        }
    }
}
